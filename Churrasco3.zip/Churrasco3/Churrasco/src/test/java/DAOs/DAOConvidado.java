package DAOs;

import Entidade.Convidado;
import Entidade.Convidado;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class DAOConvidado extends DAOGenerico<Convidado> {

    public DAOConvidado() {
        super(Convidado.class);
    }

    public int autoIdConvidado() {
        Integer a = (Integer) em.createQuery("SELECT MAX(e.id) FROM Convidado e ").getSingleResult();
        if (a != null) {
            return a + 1;
        } else {
            return 1;
        }
    }

    public List<Convidado> listByNome(String nome) {
        return em.createQuery("SELECT e FROM Convidado e WHERE e.nome LIKE :nome").setParameter("nome", "%" + nome + "%").getResultList();
    }

    public List<Convidado> listById(int id) {
        return em.createQuery("SELECT e FROM Convidado e WHERE e.id = :id").setParameter("id", id).getResultList();
    }

    public List<Convidado> listInOrderNome() {
        return em.createQuery("SELECT e FROM Convidado e ORDER BY e.nome").getResultList();
    }

    public List<Convidado> listInOrderId() {
        return em.createQuery("SELECT e FROM Convidado e ORDER BY e.id").getResultList();
    }

    public List<String> listInOrderNomeStrings(String qualOrdem) {
        List<Convidado> lf;
        if (qualOrdem.equals("id")) {
            lf = listInOrderId();
        } else {
            lf = listInOrderNome();
        }

        List<String> ls = new ArrayList<>();
        for (int i = 0; i < lf.size(); i++) {
            ls.add(lf.get(i).getId() + "-" + lf.get(i).getNome());
        }
        return ls;
    }
}
