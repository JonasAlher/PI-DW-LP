package Entidade;

import java.text.SimpleDateFormat;
import java.util.Date; 
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.Persistence;

public class DAOGenerico<T> {

    public static EntityManager em = Persistence.createEntityManagerFactory("UP").createEntityManager();
    private Class clazz;

    public DAOGenerico(Class clazz) {
        this.clazz = clazz;
    }

 public Date stringDate(String dt){
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yy");
        sdf.setLenient(false); 
        Date data=null;
        try {
            data=sdf.parse(dt);
        } catch (Exception e) {
            System.out.println("Erro na data!");
        }
        return data;
    }
    public String converteDateString(Date data){
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yy");
        sdf.setLenient(false); 
        String dt= null;
        try {
            dt=sdf.format(data);
        } catch (Exception err) {
            System.out.println("Erro na data!!");
        }
        return dt;}
    public void inserir(T e) {
        em.getTransaction().begin();
        em.persist(e);
        em.getTransaction().commit();
    }

    public void atualizar(T e) {
        em.getTransaction().begin();
        em.merge(e);
        em.getTransaction().commit();
    }

    public void remover(T e) {
        em.getTransaction().begin();
        em.remove(e);
        em.getTransaction().commit();
    }

    public T obter(Long id) {
        return (T) em.find(clazz, id);
    }

    public T obter(Integer id) {
        return (T) em.find(clazz, id);
    }

    public List<T> list() {
        return em.createQuery("SELECT e FROM " + clazz.getSimpleName() + " e").getResultList();
    }
}

